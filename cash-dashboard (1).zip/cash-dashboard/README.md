# Cash Dashboard (Cloudflare Worker + D1)
1. npm install
2. npx wrangler login
3. npx wrangler d1 create cash_dashboard   -> copy database_id into wrangler.toml
4. In wrangler.toml set ADMINS to your email
5. npx wrangler d1 execute cash_dashboard --remote --file=schema.sql
6. npx wrangler deploy                      -> prints your https://cash-dashboard.<account>.workers.dev link
7. Cloudflare dashboard > Zero Trust > Access: protect the whole app (email one-time PIN), then upload at /admin
