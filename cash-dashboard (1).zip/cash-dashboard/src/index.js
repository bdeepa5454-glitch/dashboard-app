const CATS = ["Dyson", "Samsung", "Vivo", "Garments"];
const norm = s => String(s ?? "").replace(/\u00a0/g, " ").trim();
const cleanArea = a => { a = norm(a).replace(/^\d+-/, ""); return a === "Banglore" ? "Bangalore" : a || "Unmapped"; };
const fmt = d => new Date(d + "T00:00:00Z").toLocaleDateString("en-GB", { day: "2-digit", month: "short", timeZone: "UTC" });
const json = (o, s = 200) => new Response(JSON.stringify(o), { status: s, headers: { "content-type": "application/json", "cache-control": "no-store" } });

async function data(env, url) {
  const m = url.searchParams.get("m") || (await env.DB.prepare("SELECT MAX(substr(date,1,7)) m FROM ledger").first()).m;
  if (!m) return json({ D: [], days: [], first: null, asOf: null, months: [] });
  const rows = (await env.DB.prepare("SELECT cat,store,area,date,open,pos,dep FROM ledger WHERE substr(date,1,7)=? ORDER BY date").bind(m).all()).results;
  const rem = {};
  for (const r of (await env.DB.prepare("SELECT cat,store,remark FROM remarks").all()).results) rem[r.cat + "|" + r.store] = r.remark || "";
  const dates = [...new Set(rows.map(r => r.date))];
  const days = dates.slice(-7), g = {};
  for (const r of rows) {
    const k = r.cat + "|" + r.store;
    const o = g[k] ??= { cat: r.cat, store: r.store, area: "", first: r.date, open: 0, pos: 0, dep: 0, last: "", by: {} };
    if (!o.area && norm(r.area)) o.area = r.area;
    if (r.date === o.first) o.open += r.open;
    o.pos += r.pos; o.dep += r.dep;
    if (r.dep > 0) o.last = r.date;
    const b = o.by[r.date] ??= [0, 0]; b[0] += r.pos; b[1] += r.dep;
  }
  const D = Object.values(g).sort((a, b) => CATS.indexOf(a.cat) - CATS.indexOf(b.cat)).map(o =>
    [o.cat, cleanArea(o.area), o.store, o.open, o.pos, o.dep, o.dep - (o.pos + o.open), rem[o.cat + "|" + o.store] || "", o.last ? fmt(o.last) : "-", days.map(d => o.by[d] || [0, 0])]);
  const months = (await env.DB.prepare("SELECT DISTINCT substr(date,1,7) m FROM ledger ORDER BY m DESC").all()).results.map(r => r.m);
  return json({ D, days: days.map(fmt), first: dates[0], asOf: dates.at(-1), months });
}

async function upload(env, req) {
  const email = (req.headers.get("cf-access-authenticated-user-email") || "").toLowerCase();
  const ok = env.DEV === "1" || (env.ADMINS || "").toLowerCase().split(",").map(s => s.trim()).includes(email);
  if (!ok) return json({ error: "Not an admin" }, 403);
  const b = await req.json();
  if (!CATS.includes(b.cat)) return json({ error: "Bad category" }, 400);
  const st = [];
  if (b.kind === "ledger") {
    if (b.first) st.push(env.DB.prepare(`DELETE FROM ledger WHERE cat=? AND substr(date,1,7) IN (${b.months.map(() => "?").join(",")})`).bind(b.cat, ...b.months));
    for (let i = 0; i < b.rows.length; i += 10) {
      const c = b.rows.slice(i, i + 10);
      st.push(env.DB.prepare(`INSERT INTO ledger(cat,store,area,date,open,pos,dep) VALUES ${c.map(() => "(?,?,?,?,?,?,?)").join(",")}`)
        .bind(...c.flatMap(r => [b.cat, norm(r[0]), norm(r[1]), r[2], +r[3] || 0, +r[4] || 0, +r[5] || 0])));
    }
  } else if (b.kind === "remarks") {
    st.push(env.DB.prepare("DELETE FROM remarks WHERE cat=?").bind(b.cat));
    for (let i = 0; i < b.rows.length; i += 30) {
      const c = b.rows.slice(i, i + 30);
      st.push(env.DB.prepare(`INSERT OR REPLACE INTO remarks(cat,store,remark) VALUES ${c.map(() => "(?,?,?)").join(",")}`).bind(...c.flatMap(r => [b.cat, norm(r[0]), norm(r[1])])));
    }
  } else return json({ error: "Bad kind" }, 400);
  await env.DB.batch(st);
  return json({ ok: true, rows: b.rows.length });
}

export default {
  async fetch(req, env) {
    const url = new URL(req.url);
    if (url.pathname === "/api/data") return data(env, url);
    if (url.pathname === "/api/upload" && req.method === "POST") return upload(env, req);
    return new Response("Not found", { status: 404 });
  }
};
